import sqlite3

conn = sqlite3.connect("database.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS reports (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  batch_id TEXT,
  roll INTEGER,
  name TEXT,
  attendance INTEGER,
  internal INTEGER,
  assignment INTEGER,
  study_hours INTEGER,
  prev_gpa REAL,
  predicted_grade TEXT
)
""")

conn.commit()
conn.close()
print("Database ready")
