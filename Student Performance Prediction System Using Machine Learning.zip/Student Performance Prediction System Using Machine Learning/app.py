from flask import Flask, render_template, request, redirect, url_for, session
import pandas as pd
import pickle
import sqlite3
import os
import uuid

app = Flask(__name__)
app.secret_key = "mca_project_secret"

# -----------------------------
# Load ML model
# -----------------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "model", "student_model.pkl")

model = pickle.load(open(MODEL_PATH, "rb"))

# -----------------------------
# Database helper
# -----------------------------
def get_db_connection():
    return sqlite3.connect("database.db")

# -----------------------------
# Login Page
# -----------------------------
@app.route("/", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if username == "admin" and password == "1234":
            session["user"] = username
            return redirect(url_for("dashboard"))

    return render_template("index.html")

# -----------------------------
# Dashboard
# -----------------------------
@app.route("/dashboard")
def dashboard():
    if "user" not in session:
        return redirect(url_for("login"))
    return render_template("dashboard.html")

# -----------------------------
# Upload & Analyze
# -----------------------------
@app.route("/upload", methods=["GET", "POST"])
def upload():
    if "user" not in session:
        return redirect(url_for("login"))

    if request.method == "POST":
        file = request.files["file"]
        data = pd.read_csv(file)

        batch_id = str(uuid.uuid4())[:8]

        conn = get_db_connection()
        cursor = conn.cursor()

        for _, row in data.iterrows():
            prediction = model.predict([[
                row["Attendance"],
                row["Internal"],
                row["Assignment"],
                row["StudyHours"],
                row["PrevGPA"]
            ]])

            grade_map = {0: "D", 1: "C", 2: "B", 3: "A"}
            grade = grade_map[prediction[0]]

            cursor.execute("""
                INSERT INTO reports
                (batch_id, roll, name, attendance, internal, assignment, study_hours, prev_gpa, predicted_grade)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                batch_id,
                row["RollNo"],
                row["Name"],
                row["Attendance"],
                row["Internal"],
                row["Assignment"],
                row["StudyHours"],
                row["PrevGPA"],
                grade
            ))

        conn.commit()
        conn.close()

        return redirect(url_for("reports", batch=batch_id))

    return render_template("upload.html")

# -----------------------------
# View Reports + Chart + Batch Selector
# -----------------------------
@app.route("/reports")
def reports():
    if "user" not in session:
        return redirect(url_for("login"))

    batch = request.args.get("batch")

    conn = get_db_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT DISTINCT batch_id FROM reports")
    batches = [b[0] for b in cursor.fetchall()]

    if batch:
        cursor.execute("SELECT * FROM reports WHERE batch_id=?", (batch,))
    else:
        cursor.execute("SELECT * FROM reports")

    rows = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]

    cursor.execute("""
        SELECT predicted_grade, COUNT(*)
        FROM reports
        GROUP BY predicted_grade
    """)
    grade_counts = dict(cursor.fetchall())

    conn.close()

    return render_template(
        "reports.html",
        rows=rows,
        columns=columns,
        batches=batches,
        selected_batch=batch,
        grade_counts=grade_counts
    )

# -----------------------------
# Logout
# -----------------------------
@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

# -----------------------------
# Run App
# -----------------------------
if __name__ == "__main__":
    app.run(debug=True)
